package com.oauth2.controllers;

import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.oauth2.configurations.OAuth2ClientConfig;

@RestController
//@RequestMapping("/api")
public class ResourceController {

	org.slf4j.Logger log = LoggerFactory.getLogger(ResourceController.class);
    @GetMapping("/resource")
    public ResponseEntity<String> getResource() {
    	log.info("In controller class.");
        return ResponseEntity.ok("This is a protected resource");
    }

}
