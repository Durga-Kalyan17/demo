package com.oauth2.configurations;

import java.util.Arrays;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.grant.client.ClientCredentialsResourceDetails;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;

import ch.qos.logback.classic.Logger;

@Configuration
@EnableOAuth2Client
public class OAuth2ClientConfig {
	
	/*
	 * @Value("${spring.security.oauth2.client.provider.google.token-uri}") private
	 * String tokenUri;
	 */
	
	/*
	 * @Value("${spring.security.oauth2.client.registration.google.client-id}")
	 * private String clientId;
	 * 
	 * @Value("${spring.security.oauth2.client.registration.google.client-secret}")
	 * private String clientSecret;
	 */
	
	org.slf4j.Logger log = LoggerFactory.getLogger(OAuth2ClientConfig.class);
	
	
	
    @Bean
    public OAuth2ProtectedResourceDetails resourceDetails() {
        ClientCredentialsResourceDetails details = new ClientCredentialsResourceDetails();
       // details.setAccessTokenUri("https://oauth2.googleapis.com/token");
        details.setClientId("99288457895-8n5d9u73dq05pdi7hhagffjc0smnjrp7.apps.googleusercontent.com");
        details.setClientSecret("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");
        //details.setGrantType("client_credentials");
        //details.setScope(Arrays.asList("email", "profile"));

        log.info("details : " + details);
        return details;
    }

    @Bean
    public OAuth2RestTemplate restTemplate() {
        OAuth2RestTemplate template = new OAuth2RestTemplate(resourceDetails());
        
        return template;
    }
}

