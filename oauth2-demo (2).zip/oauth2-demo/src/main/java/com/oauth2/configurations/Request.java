package com.oauth2.configurations;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;

public class Request {
	
	@Autowired
	private OAuth2RestTemplate restTemplate;
	
	org.slf4j.Logger log = LoggerFactory.getLogger(Request.class);

	public void makeRequest() {
		log.info(" In request class : ");
	    String url = "http://localhost:8080/resource";
	    log.info("url : " + url);
	    String result = restTemplate.getForObject(url, String.class);
	    log.info("result : " + result);
	    System.out.println("RESULT" + result);
	}

}
